#include "mylibraries.h"

int main(void)
{
	int n, m;
	PBM_t photo;

	startprogram(&photo, &n, &m);

	endprogram(photo, n, m);

	return 0;
}
