#include "marching.h"

void comenzi(char comanda[101], int ***r, int *n, int *m,
			 RGB_t ***ppm, int *prag);
